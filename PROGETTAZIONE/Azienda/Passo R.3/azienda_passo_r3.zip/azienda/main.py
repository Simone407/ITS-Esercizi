from beartype.claw import beartype_package
from azienda.test import test

beartype_package("azienda")

test()